const token = "novos_token";
const expireDate = "novos_expire";

// base Url for axios;
const baseUrl = "https://novos-backend.herokuapp.com/";

export { token, expireDate, baseUrl}
