<template>
    <div class="login-footer">
        <p class="text-muted">
            Bane's Novos Task with Vue
        </p>
    </div>
</template>

<script>
  export default {
    name: "LoginFooter",
  }
</script>

<style scoped lang="scss">
    .login-footer {
        padding: 0.5rem 2.5rem;
        position: absolute;
        bottom: 0;
    }
</style>
