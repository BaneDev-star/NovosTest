<template>
    <div class="register-footer">
        <p class="text-muted">
            Bane's Novos Task with Vue
        </p>
    </div>
</template>

<script>
  export default {
    name: "RegisterFooter",
  }
</script>

<style scoped lang="scss">
    .register-footer {
        padding: 0.5rem 2.5rem;
        position: absolute;
        bottom: 0;
    }
</style>
